Hướng cài đặt website demo laravel:

Bước 1: Tải toàn bộ file demoshopclothes và file database 'shop_phamhai.sql'.

Bước 2: Khởi động máy chủ ảo Xampp.

Bước 3: Di chuyển file demoshopclothes vào thư mục XAMPP/htdoc

Bước 4: Mở file demoshopclothes trong giao diện code (mình xài visual studio code).

Bước 5: Truy cập vào 'http://localhost/phpmyadmin/' và import file database 'shop_phamhai.sql'.

Bước 6: Tại giao diện code của file demoshopclothes, mở terminal và chạy câu lệnh 'php artisan serve'.

Bước 7: Truy cập 'http://127.0.0.1:8000/' để chạy website.

Giao diện sẽ bao gồm:

Giao diện trang Chủ: 'http://127.0.0.1:8000/'

Giao diện Trang Admin: 'http://127.0.0.1:8000/admin'. (Tài khoản và mật khẩu sẽ được cung cấp trên màn hình đăng nhập)
